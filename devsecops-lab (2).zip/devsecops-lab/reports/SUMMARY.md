# Vulnerability Scan Results — Real npm audit Output

## BEFORE fix (original package.json: express@4.17.1, lodash@4.17.19)
- **8 vulnerabilities found: 5 High, 3 Low**
- Key issues:
  - `lodash <=4.17.23` — Command Injection, ReDoS, Prototype Pollution (High)
  - `express <=4.21.0` (via body-parser, path-to-regexp, qs, send) — DoS, ReDoS, Prototype Pollution, template injection XSS (High)

## Fix Applied
```bash
npm audit fix --force
```
Updated:
- `express` → `^4.22.2`
- `lodash` → `^4.18.1`

## AFTER fix
- **0 vulnerabilities found**
- App re-verified working: `node server.js` → responds correctly on port 3000

This before/after pair is your evidence for Deliverable #3: "Evidence of fixed vulnerabilities and
improved security posture" (Section 11.6).

Full JSON reports: `scan-report-BEFORE-fix.json`, `scan-report-AFTER-fix.json`
